# Stack Size Tweaks (Fabric 1.21.4)

- Build: đẩy lên GitHub -> tab Actions -> tải artifact `stacksizetweaks-jar`.
- Build local: `gradle build` (Gradle 8.12, Java 21) -> `build/libs/stacksizetweaks-1.0.0.jar`.
- Config: `config/stacksizetweaks.json`. Cần cài mod ở CẢ client và server, cùng config.
- GUI: cài Mod Menu + Cloth Config trên client.
