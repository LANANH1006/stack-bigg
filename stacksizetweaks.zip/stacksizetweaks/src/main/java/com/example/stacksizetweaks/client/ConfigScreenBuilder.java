package com.example.stacksizetweaks.client;

import com.example.stacksizetweaks.config.StackSizeConfig;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

/** Dựng màn hình cấu hình bằng Cloth Config. Có thể gõ số trực tiếp vào ô. */
public final class ConfigScreenBuilder {
    private ConfigScreenBuilder() {}

    public static Screen build(Screen parent) {
        StackSizeConfig cfg = StackSizeConfig.get();

        ConfigBuilder builder = ConfigBuilder.create()
                .setParentScreen(parent)
                .setTitle(Text.translatable("stacksizetweaks.title"))
                .setSavingRunnable(StackSizeConfig::saveAndReload);

        ConfigEntryBuilder eb = builder.entryBuilder();

        // ----- Tab 1: các nhóm -----
        ConfigCategory groups = builder.getOrCreateCategory(Text.translatable("stacksizetweaks.category.groups"));
        groups.addEntry(eb.startBooleanToggle(Text.translatable("stacksizetweaks.option.useSliders"), cfg.useSliders)
                .setDefaultValue(false)
                .setTooltip(Text.translatable("stacksizetweaks.tooltip.useSliders"))
                .setSaveConsumer(v -> cfg.useSliders = v)
                .build());
        addInt(groups, eb, "blocks", cfg.blocks, 64, v -> cfg.blocks = v);
        addInt(groups, eb, "ingredients", cfg.ingredients, 64, v -> cfg.ingredients = v);
        addInt(groups, eb, "food", cfg.food, 64, v -> cfg.food = v);
        addInt(groups, eb, "items16", cfg.items16, 16, v -> cfg.items16 = v);
        addInt(groups, eb, "stews", cfg.stews, 1, v -> cfg.stews = v);
        addInt(groups, eb, "potions", cfg.potions, 1, v -> cfg.potions = v);
        addInt(groups, eb, "buckets", cfg.buckets, 1, v -> cfg.buckets = v);
        addInt(groups, eb, "enchantedBooks", cfg.enchantedBooks, 1, v -> cfg.enchantedBooks = v);
        addInt(groups, eb, "discs", cfg.discs, 1, v -> cfg.discs = v);

        // ----- Tab 2: ghi đè từng vật phẩm -----
        ConfigCategory overrides = builder.getOrCreateCategory(Text.translatable("stacksizetweaks.category.overrides"));
        overrides.addEntry(eb.startStrList(Text.translatable("stacksizetweaks.option.overrides"), cfg.overridesAsList())
                .setDefaultValue(List.of())
                .setExpanded(true)
                .setTooltip(Text.translatable("stacksizetweaks.tooltip.overrides"))
                .setCellErrorSupplier(s -> StackSizeConfig.parseLine(s) == null
                        ? Optional.of(Text.translatable("stacksizetweaks.error.format"))
                        : Optional.empty())
                .setSaveConsumer(cfg::setOverridesFromList)
                .build());

        return builder.build();
    }

    // Thanh trượt: vị trí 0..1000 ánh xạ theo thang logarit sang 1..Integer.MAX_VALUE
    private static final int SLIDER_STEPS = 1000;

    private static int posToValue(int pos) {
        double v = Math.pow(2.0, 31.0 * pos / SLIDER_STEPS);
        return (int) Math.max(1, Math.min(Integer.MAX_VALUE, Math.round(v)));
    }

    private static int valueToPos(int value) {
        double p = SLIDER_STEPS * (Math.log(Math.max(1, value)) / Math.log(2.0)) / 31.0;
        return (int) Math.max(0, Math.min(SLIDER_STEPS, Math.round(p)));
    }

    private static void addInt(ConfigCategory cat, ConfigEntryBuilder eb, String key,
                               int current, int def, Consumer<Integer> save) {
        Text name = Text.translatable("stacksizetweaks.option." + key);
        Text tip = Text.translatable("stacksizetweaks.tooltip.group");

        if (StackSizeConfig.get().useSliders) {
            final int startPos = valueToPos(current);
            cat.addEntry(eb.startIntSlider(name, startPos, 0, SLIDER_STEPS)
                    .setDefaultValue(valueToPos(def))
                    .setTooltip(tip)
                    .setTextGetter(pos -> Text.literal(String.format("%,d", posToValue(pos))))
                    // Chỉ ghi khi người chơi thật sự kéo, tránh làm lệch giá trị do làm tròn
                    .setSaveConsumer(pos -> { if (pos != startPos) save.accept(posToValue(pos)); })
                    .build());
        } else {
            cat.addEntry(eb.startIntField(name, current)
                    .setDefaultValue(def)
                    .setMin(StackSizeConfig.MIN)
                    .setMax(StackSizeConfig.MAX)
                    .setTooltip(tip)
                    .setSaveConsumer(save)
                    .build());
        }
    }
}
