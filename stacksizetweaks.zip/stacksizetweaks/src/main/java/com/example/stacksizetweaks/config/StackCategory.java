package com.example.stacksizetweaks.config;

import java.util.function.Function;

/** Các nhóm vật phẩm và cách lấy giá trị tương ứng từ config. */
public enum StackCategory {
    BLOCKS(c -> c.blocks),
    INGREDIENTS(c -> c.ingredients),
    FOOD(c -> c.food),
    ITEMS16(c -> c.items16),
    STEWS(c -> c.stews),
    POTIONS(c -> c.potions),
    BUCKETS(c -> c.buckets),
    ENCHANTED_BOOKS(c -> c.enchantedBooks),
    DISCS(c -> c.discs);

    private final Function<StackSizeConfig, Integer> getter;

    StackCategory(Function<StackSizeConfig, Integer> getter) {
        this.getter = getter;
    }

    public int get(StackSizeConfig config) {
        return getter.apply(config);
    }
}
