package com.example.stacksizetweaks.config;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.BlockItem;
import net.minecraft.item.BucketItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.item.PotionItem;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tính stack size cho từng vật phẩm (có bộ nhớ đệm).
 * Các Mixin gọi getMaxStackSize() mỗi khi game hỏi giới hạn stack.
 *
 * Ta KHÔNG sửa Data Component của Item; thay vào đó chặn hàm getMaxCount()
 * nên cách này an toàn với mọi mod khác và với item đăng ký muộn.
 */
public final class StackSizeManager {
    /** Giá trị trả về nghĩa là "dùng giá trị vanilla". */
    public static final int VANILLA = -1;

    private static final Map<Item, Integer> CACHE = new ConcurrentHashMap<>();
    private static volatile boolean ready = false;

    private StackSizeManager() {}

    /** Chỉ bật sau khi Registry đã khởi tạo xong (tránh lỗi lúc bootstrap). */
    public static void markReady() {
        ready = true;
    }

    public static void clearCache() {
        CACHE.clear();
    }

    /** @return stack size tùy chỉnh, hoặc VANILLA (-1) nếu không đổi. */
    public static int getMaxStackSize(Item item) {
        if (!ready || item == null || item == Items.AIR) return VANILLA;

        Integer cached = CACHE.get(item);
        if (cached != null) return cached;

        Identifier id = Registries.ITEM.getId(item);
        // Vật phẩm chưa đăng ký sẽ trả về id mặc định (minecraft:air) -> không cache
        if (Registries.ITEM.getDefaultId().equals(id)) return VANILLA;

        StackSizeConfig cfg = StackSizeConfig.get();
        int value = VANILLA;

        Integer override = cfg.overrides.get(id.toString());
        if (override != null) {
            value = override;                       // ghi đè riêng có ưu tiên cao nhất
        } else {
            StackCategory cat = classify(item);
            if (cat != null) value = cat.get(cfg);
        }

        CACHE.put(item, value);
        return value;
    }

    /**
     * Phân loại vật phẩm dựa trên stack size GỐC (đọc thẳng từ component,
     * không qua getMaxCount() để tránh đệ quy).
     */
    private static StackCategory classify(Item item) {
        int vanilla = item.getComponents().getOrDefault(DataComponentTypes.MAX_STACK_SIZE, 1);

        if (item == Items.ENCHANTED_BOOK) return StackCategory.ENCHANTED_BOOKS;
        if (item.getComponents().contains(DataComponentTypes.JUKEBOX_PLAYABLE)) return StackCategory.DISCS;
        if (item instanceof PotionItem) return StackCategory.POTIONS; // gồm thuốc ném / lưu lại

        if (vanilla == 1) {
            if (item == Items.MUSHROOM_STEW || item == Items.RABBIT_STEW
                    || item == Items.BEETROOT_SOUP || item == Items.SUSPICIOUS_STEW) {
                return StackCategory.STEWS;
            }
            if (item instanceof BucketItem || item == Items.MILK_BUCKET) {
                return StackCategory.BUCKETS;
            }
            return null; // công cụ, giáp, giường... giữ nguyên
        }

        if (vanilla == 16) return StackCategory.ITEMS16;

        if (vanilla == 64) {
            if (item instanceof BlockItem) return StackCategory.BLOCKS;
            if (item.getComponents().contains(DataComponentTypes.FOOD)) return StackCategory.FOOD;
            return StackCategory.INGREDIENTS;
        }
        return null;
    }
}
