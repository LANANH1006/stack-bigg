package com.example.stacksizetweaks;

import com.example.stacksizetweaks.config.StackSizeConfig;
import com.example.stacksizetweaks.config.StackSizeManager;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Class khởi chạy chính. Chạy cả trên client lẫn server (environment "*").
 */
public class StackSizeTweaks implements ModInitializer {
    public static final String MOD_ID = "stacksizetweaks";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        // Đọc (hoặc tự tạo) file config/stacksizetweaks.json
        StackSizeConfig.get();
        // Đến đây Registry vật phẩm vanilla đã sẵn sàng -> cho phép Mixin tra cứu
        StackSizeManager.markReady();
        LOGGER.info("[StackSizeTweaks] Đã tải cấu hình stack size.");
    }
}
