package com.example.stacksizetweaks.mixin;

import net.minecraft.inventory.Inventory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Inventory mặc định giới hạn 99 mỗi ô (getMaxCountPerStack).
 * Gỡ giới hạn này; giới hạn thật do ItemStack.getMaxCount() quyết định.
 */
@Mixin(Inventory.class)
public interface InventoryMixin {

    @Inject(method = "getMaxCountPerStack", at = @At("HEAD"), cancellable = true)
    private void sst$getMaxCountPerStack(CallbackInfoReturnable<Integer> cir) {
        cir.setReturnValue(Integer.MAX_VALUE);
    }
}
