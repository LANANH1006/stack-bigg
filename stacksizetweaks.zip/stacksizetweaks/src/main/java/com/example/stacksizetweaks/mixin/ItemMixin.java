package com.example.stacksizetweaks.mixin;

import com.example.stacksizetweaks.config.StackSizeManager;
import net.minecraft.item.Item;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Chặn Item.getMaxCount() để trả về stack size theo config. */
@Mixin(Item.class)
public abstract class ItemMixin {

    @Inject(method = "getMaxCount", at = @At("HEAD"), cancellable = true, require = 0)
    private void sst$getMaxCount(CallbackInfoReturnable<Integer> cir) {
        int v = StackSizeManager.getMaxStackSize((Item) (Object) this);
        if (v != StackSizeManager.VANILLA) {
            cir.setReturnValue(v);
        }
    }
}
