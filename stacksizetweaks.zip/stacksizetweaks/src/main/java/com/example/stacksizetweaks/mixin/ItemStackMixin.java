package com.example.stacksizetweaks.mixin;

import com.example.stacksizetweaks.config.StackSizeManager;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Từ 1.20.5, ItemStack.getMaxCount() đọc trực tiếp từ Data Component
 * (không qua Item.getMaxCount()) nên phải chặn ở cả hai nơi.
 */
@Mixin(ItemStack.class)
public abstract class ItemStackMixin {

    /** Trả về stack size tùy chỉnh cho ItemStack. */
    @Inject(method = "getMaxCount", at = @At("HEAD"), cancellable = true)
    private void sst$getMaxCount(CallbackInfoReturnable<Integer> cir) {
        int v = StackSizeManager.getMaxStackSize(((ItemStack) (Object) this).getItem());
        if (v != StackSizeManager.VANILLA) {
            cir.setReturnValue(v);
        }
    }

    /**
     * Codec lưu/đọc ItemStack (NBT, file thế giới) giới hạn count trong [1, 99].
     * Nâng trần lên Integer.MAX_VALUE, nếu không stack lớn sẽ lỗi khi lưu.
     * require = 0: nếu không tìm thấy hằng số 99 thì bỏ qua, không làm crash game.
     * remap = false vì "<clinit>" và "lambda$static$N" không bị đổi tên.
     */
    @ModifyConstant(
            method = {"<clinit>", "/^lambda\\$static\\$\\d+$/"},
            constant = @Constant(intValue = 99),
            require = 0,
            remap = false)
    private static int sst$raiseCodecLimit(int original) {
        return Integer.MAX_VALUE;
    }
}
