package com.example.stacksizetweaks.config;

import com.example.stacksizetweaks.StackSizeTweaks;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.util.Identifier;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * File cấu hình: config/stacksizetweaks.json
 * Tên field = tên khóa trong file JSON.
 */
public class StackSizeConfig {
    public static final int MIN = 1;
    public static final int MAX = Integer.MAX_VALUE; // 2.147.483.647

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static volatile StackSizeConfig instance;

    /** true = GUI dùng thanh trượt (thang logarit) thay vì ô gõ số */
    public boolean useSliders = false;

    // ----- Cài đặt theo nhóm -----
    public int blocks = 64;          // khối đặt được
    public int ingredients = 64;     // nguyên liệu thô
    public int food = 64;            // thức ăn
    public int items16 = 16;         // vật phẩm gốc giới hạn 16
    public int stews = 1;            // súp / canh
    public int potions = 1;          // bình thuốc
    public int buckets = 1;          // xô đã múc
    public int enchantedBooks = 1;   // sách phép
    public int discs = 1;            // đĩa nhạc

    /** Ghi đè riêng từng vật phẩm, ví dụ "minecraft:diamond": 9999 */
    public Map<String, Integer> overrides = new LinkedHashMap<>();

    // ------------------------------------------------------------------

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve(StackSizeTweaks.MOD_ID + ".json");
    }

    /** Lấy config (tự đọc file lần đầu). */
    public static StackSizeConfig get() {
        StackSizeConfig c = instance;
        if (c == null) {
            synchronized (StackSizeConfig.class) {
                if (instance == null) {
                    instance = load();
                }
                c = instance;
            }
        }
        return c;
    }

    private static StackSizeConfig load() {
        Path file = path();
        StackSizeConfig cfg = new StackSizeConfig();
        if (Files.exists(file)) {
            try (Reader r = Files.newBufferedReader(file)) {
                StackSizeConfig read = GSON.fromJson(r, StackSizeConfig.class);
                if (read != null) cfg = read;
            } catch (Exception e) {
                StackSizeTweaks.LOGGER.error("[StackSizeTweaks] Lỗi đọc config, dùng mặc định.", e);
            }
        }
        cfg.sanitize();
        cfg.write(); // ghi lại để tự tạo file / bổ sung khóa còn thiếu
        return cfg;
    }

    /** Ghi file rồi làm mới bộ nhớ đệm stack size. */
    public static void saveAndReload() {
        StackSizeConfig cfg = get();
        cfg.sanitize();
        cfg.write();
        StackSizeManager.clearCache();
    }

    private void write() {
        try {
            Files.createDirectories(path().getParent());
            try (Writer w = Files.newBufferedWriter(path())) {
                GSON.toJson(this, w);
            }
        } catch (IOException e) {
            StackSizeTweaks.LOGGER.error("[StackSizeTweaks] Không ghi được config.", e);
        }
    }

    /** Ép mọi giá trị về khoảng hợp lệ [1, Integer.MAX_VALUE]. */
    private void sanitize() {
        blocks = clamp(blocks);
        ingredients = clamp(ingredients);
        food = clamp(food);
        items16 = clamp(items16);
        stews = clamp(stews);
        potions = clamp(potions);
        buckets = clamp(buckets);
        enchantedBooks = clamp(enchantedBooks);
        discs = clamp(discs);
        if (overrides == null) overrides = new LinkedHashMap<>();
        overrides.replaceAll((k, v) -> v == null ? 1 : clamp(v));
    }

    private static int clamp(int v) {
        return Math.max(MIN, Math.min(MAX, v));
    }

    // ----- Hỗ trợ GUI: chuyển Map <-> List "id=số" -----

    public List<String> overridesAsList() {
        return overrides.entrySet().stream().map(e -> e.getKey() + "=" + e.getValue()).toList();
    }

    public void setOverridesFromList(List<String> lines) {
        Map<String, Integer> map = new LinkedHashMap<>();
        for (String line : lines) {
            Map.Entry<String, Integer> e = parseLine(line);
            if (e != null) map.put(e.getKey(), e.getValue());
        }
        this.overrides = map;
    }

    /** Trả về null nếu dòng không hợp lệ. */
    public static Map.Entry<String, Integer> parseLine(String line) {
        if (line == null) return null;
        int idx = line.lastIndexOf('=');
        if (idx <= 0) return null;
        Identifier id = Identifier.tryParse(line.substring(0, idx).trim());
        if (id == null) return null;
        try {
            long n = Long.parseLong(line.substring(idx + 1).trim());
            return Map.entry(id.toString(), (int) Math.max(MIN, Math.min(MAX, n)));
        } catch (NumberFormatException ex) {
            return null;
        }
    }
}
